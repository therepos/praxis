# sharepoints

Internal SharePoint automation tools. Each subfolder is an independent project with its own build pipeline.

## Projects

| Project | Description | Status | Latest Release |
|---|---|---|---|
| [personnel-db](./personnel-db) | Staff & project credentials database with Annex E generator | Active | [Releases](https://github.com/USER/sharepoints/releases?q=personnel-db&expanded=true) |

## Conventions

- One folder per project at repo root
- Each project has its own `README.md`, `requirements.txt`, and GitHub Actions workflow
- Release tags follow pattern `<project-name>-v<semver>`, e.g. `personnel-db-v1.0.0`
- Path-filtered workflows — changes to one project don't trigger builds for others

## Adding a new project

1. Create folder at repo root
2. Add `<project>/README.md`, `<project>/requirements.txt`
3. Add `.github/workflows/<project>.yml` with `paths:` filter on `<project>/**`
4. Add row to project table above
