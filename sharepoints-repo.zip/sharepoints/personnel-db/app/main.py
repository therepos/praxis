"""
PersonnelDB — Annex E proposal generator.

Reads SharePoint-synced Excel export and generates personnel CV documents.
"""
import streamlit as st
from pathlib import Path

from core.config import get_config
from core.data import load_database

st.set_page_config(
    page_title="PersonnelDB",
    page_icon="📋",
    layout="wide",
    initial_sidebar_state="expanded",
)


def main():
    st.sidebar.title("📋 PersonnelDB")
    st.sidebar.caption("Annex E proposal generator")

    cfg = get_config()
    excel_path = Path(cfg.excel_path) if cfg.excel_path else None

    if not excel_path or not excel_path.exists():
        st.sidebar.error("⚠️ Database not found")
        st.error("# Setup required")
        st.markdown(
            "The app cannot find the SharePoint-synced database file.\n\n"
            "**Expected path:**\n"
            f"```\n{excel_path or '(not configured)'}\n```\n"
            "**Fix:**\n"
            "1. Confirm SharePoint sync is running\n"
            "2. Check that `personnel_export.xlsx` exists in your synced folder\n"
            "3. Use **Settings** in the sidebar to point to the correct location"
        )
        page = st.sidebar.radio("Page", ["Settings"], label_visibility="collapsed")
    else:
        try:
            db = load_database(excel_path)
            st.session_state["db"] = db
            st.sidebar.success(f"✓ Loaded {len(db.personnel)} staff, {len(db.projects)} projects")
            st.sidebar.caption(f"Last synced: {db.loaded_at:%Y-%m-%d %H:%M}")
        except Exception as e:
            st.sidebar.error(f"Load failed: {e}")
            db = None

        page = st.sidebar.radio(
            "Page",
            ["Staff Directory", "Project Library", "Generate Annex E", "Settings"],
            label_visibility="collapsed",
        )

    st.sidebar.divider()
    st.sidebar.caption(f"v{cfg.version}")
    st.sidebar.caption("[Update SharePoint Lists →](https://sharepoint.com)")

    if page == "Staff Directory":
        from pages import staff_directory
        staff_directory.render()
    elif page == "Project Library":
        from pages import project_library
        project_library.render()
    elif page == "Generate Annex E":
        from pages import generate
        generate.render()
    elif page == "Settings":
        from pages import settings
        settings.render()


if __name__ == "__main__":
    main()
