"""Annex E document generator — fills Word template, optionally exports to PDF."""
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from docxtpl import DocxTemplate

from core.data import Database

TEMPLATE_PATH = Path(__file__).parent.parent / "templates" / "annex_e_template.docx"


def _safe_filename(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "_", name).strip("_")


def generate_annex_e(
    db: Database,
    personnel_id: str,
    output_dir: Path,
    sector_tags: list[str] | None = None,
    domain_tags: list[str] | None = None,
    project_types: list[str] | None = None,
    date_range: tuple[str, str] | None = None,
    also_pdf: bool = True,
    timestamp: str | None = None,
) -> tuple[Path, Path | None]:
    """Generate an Annex E document for one person. Returns (docx_path, pdf_path or None)."""
    person = db.get_personnel(personnel_id)
    if person is None:
        raise ValueError(f"Personnel {personnel_id} not found")

    education = db.education_for(personnel_id)
    certifications = db.certifications_for(personnel_id)
    project_links = db.projects_for(
        personnel_id,
        sector_tags=sector_tags,
        domain_tags=domain_tags,
        project_types=project_types,
        date_range=date_range,
    )

    context = {
        "name": person.full_name,
        "current_position": person.current_position,
        "proposed_role": person.default_role,
        "years_of_experience": person.years_of_experience,
        "audit_start_year": person.audit_start_year,
        "education": [
            {"course": f"{e.course_name}, {e.institution}", "year": e.year_attained}
            for e in education
        ],
        "certifications": [
            {"name": c.name, "year": c.year_attained}
            for c in certifications
        ],
        "projects": [
            {
                "index": i + 1,
                "client_name": proj.client_name,
                "project_name": proj.project_name,
                "completion": f"{proj.start_period} to {proj.end_period}",
                "role": link.role_on_project,
                "description": proj.description,
                "contribution_notes": link.contribution_notes,
            }
            for i, (proj, link) in enumerate(project_links)
        ],
        "generated_at": datetime.now().strftime("%Y-%m-%d"),
    }

    if not TEMPLATE_PATH.exists():
        raise FileNotFoundError(f"Template not found: {TEMPLATE_PATH}")

    doc = DocxTemplate(str(TEMPLATE_PATH))
    doc.render(context)

    ts = timestamp or datetime.now().strftime("%Y%m%d_%H%M%S")
    base = f"AnnexE_{_safe_filename(person.full_name)}_{ts}"
    docx_path = output_dir / f"{base}.docx"
    doc.save(str(docx_path))

    pdf_path = None
    if also_pdf:
        pdf_path = _convert_to_pdf(docx_path)

    return docx_path, pdf_path


def _convert_to_pdf(docx_path: Path) -> Path | None:
    """Best-effort PDF conversion. Tries docx2pdf (Windows + Word), then LibreOffice."""
    pdf_path = docx_path.with_suffix(".pdf")

    try:
        from docx2pdf import convert
        convert(str(docx_path), str(pdf_path))
        if pdf_path.exists():
            return pdf_path
    except Exception:
        pass

    for lo in ["soffice", "libreoffice", r"C:\Program Files\LibreOffice\program\soffice.exe"]:
        try:
            result = subprocess.run(
                [lo, "--headless", "--convert-to", "pdf", "--outdir", str(pdf_path.parent), str(docx_path)],
                capture_output=True,
                timeout=60,
            )
            if result.returncode == 0 and pdf_path.exists():
                return pdf_path
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue

    return None
