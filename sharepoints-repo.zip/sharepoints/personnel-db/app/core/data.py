"""Data layer — pydantic models and Excel loader."""
from datetime import datetime
from pathlib import Path

import pandas as pd
from pydantic import BaseModel, Field


class Personnel(BaseModel):
    personnel_id: str
    full_name: str
    current_position: str
    default_role: str
    audit_start_year: int
    active: bool = True
    notes: str = ""

    @property
    def years_of_experience(self) -> int:
        return datetime.now().year - self.audit_start_year


class Education(BaseModel):
    education_id: str
    personnel_id: str
    course_name: str
    institution: str
    year_attained: int


class Certification(BaseModel):
    certification_id: str
    personnel_id: str
    name: str
    year_attained: int


class Project(BaseModel):
    project_id: str
    client_name: str
    project_name: str
    description: str
    start_period: str
    end_period: str
    project_type: str
    sector_tags: list[str] = Field(default_factory=list)
    domain_tags: list[str] = Field(default_factory=list)


class PersonnelProject(BaseModel):
    personnel_id: str
    project_id: str
    role_on_project: str
    contribution_notes: str = ""


class Database(BaseModel):
    personnel: list[Personnel]
    education: list[Education]
    certifications: list[Certification]
    projects: list[Project]
    personnel_projects: list[PersonnelProject]
    loaded_at: datetime

    def get_personnel(self, personnel_id: str) -> Personnel | None:
        return next((p for p in self.personnel if p.personnel_id == personnel_id), None)

    def get_project(self, project_id: str) -> Project | None:
        return next((p for p in self.projects if p.project_id == project_id), None)

    def education_for(self, personnel_id: str) -> list[Education]:
        return [e for e in self.education if e.personnel_id == personnel_id]

    def certifications_for(self, personnel_id: str) -> list[Certification]:
        return [c for c in self.certifications if c.personnel_id == personnel_id]

    def projects_for(
        self,
        personnel_id: str,
        sector_tags: list[str] | None = None,
        domain_tags: list[str] | None = None,
        project_types: list[str] | None = None,
        date_range: tuple[str, str] | None = None,
    ) -> list[tuple[Project, PersonnelProject]]:
        """Return (project, personnel_project) tuples for a person, with optional filters."""
        links = [pp for pp in self.personnel_projects if pp.personnel_id == personnel_id]
        results = []
        for link in links:
            proj = self.get_project(link.project_id)
            if proj is None:
                continue
            if project_types and proj.project_type not in project_types:
                continue
            if sector_tags and not (set(sector_tags) & set(proj.sector_tags)):
                continue
            if domain_tags and not (set(domain_tags) & set(proj.domain_tags)):
                continue
            if date_range and not _project_in_window(proj, date_range):
                continue
            results.append((proj, link))
        return results


def _project_in_window(proj: Project, window: tuple[str, str]) -> bool:
    """Check if project's active period overlaps with window (YYYY-MM strings)."""
    win_start, win_end = window
    proj_end = "9999-99" if proj.end_period.lower() == "present" else proj.end_period
    return proj.start_period <= win_end and proj_end >= win_start


def _split_tags(value) -> list[str]:
    if pd.isna(value) or not value:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    return [t.strip() for t in str(value).split(",") if t.strip()]


def load_database(path: Path) -> Database:
    """Load all 5 sheets from the SharePoint-synced Excel export."""
    sheets = pd.read_excel(path, sheet_name=None, dtype=str, keep_default_na=False)

    required = {"Personnel", "Education", "Certifications", "Projects", "Personnel_Projects"}
    missing = required - set(sheets.keys())
    if missing:
        raise ValueError(f"Excel file missing required sheets: {missing}")

    personnel = [
        Personnel(
            personnel_id=r["personnel_id"],
            full_name=r["full_name"],
            current_position=r["current_position"],
            default_role=r["default_role"],
            audit_start_year=int(float(r["audit_start_year"])),
            active=str(r.get("active", "True")).strip().lower() in ("true", "yes", "1"),
            notes=r.get("notes", ""),
        )
        for _, r in sheets["Personnel"].iterrows()
        if r.get("personnel_id")
    ]

    education = [
        Education(
            education_id=r["education_id"],
            personnel_id=r["personnel_id"],
            course_name=r["course_name"],
            institution=r["institution"],
            year_attained=int(float(r["year_attained"])),
        )
        for _, r in sheets["Education"].iterrows()
        if r.get("education_id")
    ]

    certifications = [
        Certification(
            certification_id=r["certification_id"],
            personnel_id=r["personnel_id"],
            name=r["name"],
            year_attained=int(float(r["year_attained"])),
        )
        for _, r in sheets["Certifications"].iterrows()
        if r.get("certification_id")
    ]

    projects = [
        Project(
            project_id=r["project_id"],
            client_name=r["client_name"],
            project_name=r["project_name"],
            description=r["description"],
            start_period=r["start_period"],
            end_period=r["end_period"],
            project_type=r["project_type"],
            sector_tags=_split_tags(r.get("sector_tags", "")),
            domain_tags=_split_tags(r.get("domain_tags", "")),
        )
        for _, r in sheets["Projects"].iterrows()
        if r.get("project_id")
    ]

    personnel_projects = [
        PersonnelProject(
            personnel_id=r["personnel_id"],
            project_id=r["project_id"],
            role_on_project=r["role_on_project"],
            contribution_notes=r.get("contribution_notes", ""),
        )
        for _, r in sheets["Personnel_Projects"].iterrows()
        if r.get("personnel_id") and r.get("project_id")
    ]

    return Database(
        personnel=personnel,
        education=education,
        certifications=certifications,
        projects=projects,
        personnel_projects=personnel_projects,
        loaded_at=datetime.now(),
    )
