"""Configuration — Excel file location, version, user preferences."""
import json
import os
from dataclasses import dataclass, asdict
from pathlib import Path

VERSION = "0.1.0"

CONFIG_DIR = Path(os.environ.get("APPDATA", Path.home())) / "PersonnelDB"
CONFIG_FILE = CONFIG_DIR / "config.json"


@dataclass
class Config:
    excel_path: str = ""
    output_dir: str = ""
    version: str = VERSION

    @classmethod
    def load(cls) -> "Config":
        if CONFIG_FILE.exists():
            try:
                data = json.loads(CONFIG_FILE.read_text())
                return cls(
                    excel_path=data.get("excel_path", ""),
                    output_dir=data.get("output_dir", ""),
                    version=VERSION,
                )
            except Exception:
                pass
        return cls(
            excel_path=_default_excel_guess(),
            output_dir=str(Path.home() / "Documents" / "PersonnelDB_Output"),
        )

    def save(self):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(asdict(self), indent=2))


def _default_excel_guess() -> str:
    """Try to guess the SharePoint-synced location."""
    home = Path.home()
    candidates = list(home.glob("*/PersonnelDB/personnel_export.xlsx"))
    if candidates:
        return str(candidates[0])
    return ""


_cached_config: Config | None = None


def get_config() -> Config:
    global _cached_config
    if _cached_config is None:
        _cached_config = Config.load()
    return _cached_config


def reload_config():
    global _cached_config
    _cached_config = None
    return get_config()
