"""Generate Annex E page — produce filled Word + PDF documents."""
from datetime import datetime
from pathlib import Path

import streamlit as st

from core.config import get_config
from core.generator import generate_annex_e


def render():
    st.title("Generate Annex E")
    db = st.session_state.get("db")
    if db is None:
        st.warning("Database not loaded.")
        return

    cfg = get_config()
    output_dir = Path(cfg.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    st.markdown("### 1. Select staff")
    active = [p for p in db.personnel if p.active]
    options = {f"{p.full_name} ({p.personnel_id}) — {p.current_position}": p.personnel_id for p in active}
    selected_labels = st.multiselect("Staff to include", list(options.keys()))
    selected_ids = [options[label] for label in selected_labels]

    st.markdown("### 2. Filter projects")
    c1, c2 = st.columns(2)
    with c1:
        all_sectors = sorted({t for p in db.projects for t in p.sector_tags})
        f_sectors = st.multiselect("Sector tags (any-of)", all_sectors,
                                   help="Show only projects with at least one of these sector tags. Empty = no filter.")
    with c2:
        all_domains = sorted({t for p in db.projects for t in p.domain_tags})
        f_domains = st.multiselect("Domain tags (any-of)", all_domains)

    relevant_only = st.checkbox(
        "IMDA 'relevant' filter — internal_audit only (exclude ISO, SSAE3402, etc.)",
        value=True,
    )

    st.markdown("### 3. Date window")
    c1, c2 = st.columns(2)
    with c1:
        start = st.text_input("Window start (YYYY-MM)", value="2024-04")
    with c2:
        end = st.text_input("Window end (YYYY-MM)", value="2026-03")

    st.markdown("### 4. Output")
    c1, c2 = st.columns(2)
    with c1:
        also_pdf = st.checkbox("Also generate PDF", value=True)
    with c2:
        st.caption(f"Output folder: `{output_dir}`")

    st.divider()

    if st.button("Generate", type="primary", disabled=not selected_ids):
        if not selected_ids:
            st.error("Pick at least one staff member.")
            return

        project_types = ["internal_audit"] if relevant_only else None
        date_range = (start, end) if start and end else None
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        results = []
        progress = st.progress(0.0)
        for i, pid in enumerate(selected_ids):
            person = db.get_personnel(pid)
            try:
                docx_path, pdf_path = generate_annex_e(
                    db=db,
                    personnel_id=pid,
                    output_dir=output_dir,
                    sector_tags=f_sectors or None,
                    domain_tags=f_domains or None,
                    project_types=project_types,
                    date_range=date_range,
                    also_pdf=also_pdf,
                    timestamp=timestamp,
                )
                results.append((person.full_name, docx_path, pdf_path, None))
            except Exception as e:
                results.append((person.full_name, None, None, str(e)))
            progress.progress((i + 1) / len(selected_ids))

        st.success(f"Done. Generated {sum(1 for r in results if r[1])} of {len(results)}.")
        st.divider()

        for name, docx, pdf, err in results:
            if err:
                st.error(f"❌ {name}: {err}")
            else:
                st.markdown(f"✅ **{name}**")
                cols = st.columns(2)
                with cols[0]:
                    if docx:
                        st.markdown(f"📄 [{docx.name}]({docx.as_uri()})")
                with cols[1]:
                    if pdf:
                        st.markdown(f"📑 [{pdf.name}]({pdf.as_uri()})")
