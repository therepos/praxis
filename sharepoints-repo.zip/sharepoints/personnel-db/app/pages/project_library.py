"""Project Library page — browse and filter projects."""
import streamlit as st


def render():
    st.title("Project Library")
    db = st.session_state.get("db")
    if db is None:
        st.warning("Database not loaded.")
        return

    all_sectors = sorted({t for p in db.projects for t in p.sector_tags})
    all_domains = sorted({t for p in db.projects for t in p.domain_tags})
    all_types = sorted({p.project_type for p in db.projects})

    c1, c2, c3 = st.columns(3)
    with c1:
        f_sectors = st.multiselect("Sector", all_sectors)
    with c2:
        f_domains = st.multiselect("Domain", all_domains)
    with c3:
        f_types = st.multiselect("Type", all_types, default=["internal_audit"] if "internal_audit" in all_types else [])

    search = st.text_input("Search client or project", placeholder="e.g. Ministry of Education")

    filtered = db.projects
    if f_sectors:
        filtered = [p for p in filtered if set(f_sectors) & set(p.sector_tags)]
    if f_domains:
        filtered = [p for p in filtered if set(f_domains) & set(p.domain_tags)]
    if f_types:
        filtered = [p for p in filtered if p.project_type in f_types]
    if search:
        s = search.lower()
        filtered = [p for p in filtered if s in p.client_name.lower() or s in p.project_name.lower()]

    st.caption(f"Showing {len(filtered)} of {len(db.projects)} projects")
    st.divider()

    for proj in filtered:
        with st.expander(f"**{proj.client_name}** — {proj.project_name} ({proj.project_id})"):
            st.markdown(f"**Period:** {proj.start_period} → {proj.end_period}")
            st.markdown(f"**Type:** `{proj.project_type}`")
            st.markdown(f"**Sectors:** {', '.join(proj.sector_tags) or '-'}")
            st.markdown(f"**Domains:** {', '.join(proj.domain_tags) or '-'}")
            st.markdown(f"**Description:** {proj.description}")

            assignees = [pp for pp in db.personnel_projects if pp.project_id == proj.project_id]
            if assignees:
                st.markdown(f"**Team ({len(assignees)})**")
                for a in assignees:
                    person = db.get_personnel(a.personnel_id)
                    if person:
                        st.markdown(f"- {person.full_name} — _{a.role_on_project}_")
