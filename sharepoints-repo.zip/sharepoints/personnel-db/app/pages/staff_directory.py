"""Staff Directory page — browse and search personnel."""
import streamlit as st


def render():
    st.title("Staff Directory")
    db = st.session_state.get("db")
    if db is None:
        st.warning("Database not loaded.")
        return

    col1, col2, col3 = st.columns([3, 1, 1])
    with col1:
        search = st.text_input("Search by name or ID", placeholder="e.g. Ann Sheng or P001")
    with col2:
        show_inactive = st.checkbox("Show inactive", value=False)
    with col3:
        st.metric("Total active", sum(1 for p in db.personnel if p.active))

    filtered = db.personnel
    if not show_inactive:
        filtered = [p for p in filtered if p.active]
    if search:
        s = search.lower()
        filtered = [p for p in filtered if s in p.full_name.lower() or s in p.personnel_id.lower()]

    st.divider()

    if not filtered:
        st.info("No staff match.")
        return

    for p in filtered:
        with st.expander(f"**{p.full_name}** — {p.current_position} ({p.personnel_id})"):
            c1, c2 = st.columns(2)
            with c1:
                st.markdown(f"**Role default:** {p.default_role}")
                st.markdown(f"**Years of experience:** {p.years_of_experience} (since {p.audit_start_year})")
                st.markdown(f"**Active:** {'Yes' if p.active else 'No'}")
                if p.notes:
                    st.caption(p.notes)

            with c2:
                edu = db.education_for(p.personnel_id)
                if edu:
                    st.markdown("**Education**")
                    for e in edu:
                        st.markdown(f"- {e.course_name}, {e.institution} ({e.year_attained})")
                certs = db.certifications_for(p.personnel_id)
                if certs:
                    st.markdown("**Certifications**")
                    for c in certs:
                        st.markdown(f"- {c.name} ({c.year_attained})")

            projs = db.projects_for(p.personnel_id)
            if projs:
                st.markdown(f"**Projects ({len(projs)})**")
                for proj, link in projs:
                    tags = ", ".join(proj.sector_tags + proj.domain_tags)
                    st.markdown(
                        f"- **{proj.client_name}** — _{link.role_on_project}_  \n"
                        f"  {proj.project_name} ({proj.start_period} → {proj.end_period})  \n"
                        f"  Tags: `{tags}`"
                    )
