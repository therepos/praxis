"""Settings page — Excel and output paths."""
from pathlib import Path

import streamlit as st

from core.config import get_config, reload_config


def render():
    st.title("Settings")
    cfg = get_config()

    st.markdown("### Database location")
    st.caption("Path to the SharePoint-synced `personnel_export.xlsx` on your local PC.")
    new_excel = st.text_input(
        "Excel path",
        value=cfg.excel_path,
        placeholder=r"C:\Users\you\YourCompany\PersonnelDB - Documents\personnel_export.xlsx",
    )
    if new_excel:
        path = Path(new_excel)
        if path.exists():
            st.success(f"✓ File found ({path.stat().st_size // 1024} KB)")
        else:
            st.error("✗ File not found at that path")

    st.markdown("### Output folder")
    st.caption("Where generated Annex E documents are saved.")
    new_output = st.text_input("Output folder", value=cfg.output_dir)

    if st.button("Save settings", type="primary"):
        cfg.excel_path = new_excel
        cfg.output_dir = new_output
        cfg.save()
        reload_config()
        st.success("Saved. Reloading…")
        st.rerun()

    st.divider()
    st.markdown("### Diagnostics")
    st.code(f"Config file: {cfg.__class__.__module__}\nVersion: {cfg.version}")
