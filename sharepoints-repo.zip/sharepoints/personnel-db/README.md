# personnel-db

Staff & project credentials database with automated Annex E proposal generator.

## Quick install (end users)

1. Download `PersonnelDB.exe` from the [latest release](https://github.com/USER/sharepoints/releases?q=personnel-db&expanded=true)
2. Place the `.exe` anywhere on your machine (e.g. Desktop)
3. Make sure your SharePoint folder is OneDrive-synced to your PC
4. Double-click the `.exe` — your browser will open automatically
5. Done

## What it does

- Reads staff credentials and project history from SharePoint Lists (synced via Power Automate)
- Lets you filter staff and projects by tags (sector, domain, date range)
- Generates Annex E personnel CV documents in Word and PDF format

## Updating the database

You don't update via this app. Update via SharePoint Lists directly:

- **Add/edit staff** → SharePoint site → Personnel List
- **Add/edit projects** → SharePoint site → Projects List
- **Link staff to projects** → SharePoint site → Personnel_Projects List

Changes appear in the app within ~1 hour (Power Automate export interval).

## Folder structure

```
personnel-db/
├── app/                    Streamlit application
│   ├── main.py             Entry point
│   ├── core/               Data layer, generator, lock
│   ├── pages/              UI pages
│   └── templates/          Word templates
├── scripts/                Build & migration scripts
├── tests/
└── docs/
    ├── sharepoint-setup.md     One-time SharePoint Lists setup
    └── power-automate-setup.md One-time Power Automate flow setup
```

## For developers

```bash
cd personnel-db
pip install -r requirements.txt
streamlit run app/main.py
```

Builds to `.exe` automatically on tag push: `personnel-db-v*`

## Documentation

- [SharePoint Lists setup](./docs/sharepoint-setup.md) — one-time, do this first
- [Power Automate setup](./docs/power-automate-setup.md) — one-time, do this second
- [Developer guide](./docs/developer.md) — for contributors
