"""Tests for data layer."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "app"))

from core.data import Project, _project_in_window


def test_project_in_window_overlap():
    p = Project(
        project_id="X", client_name="C", project_name="N", description="D",
        start_period="2023-01", end_period="2025-06", project_type="internal_audit",
    )
    assert _project_in_window(p, ("2024-04", "2026-03"))


def test_project_in_window_outside():
    p = Project(
        project_id="X", client_name="C", project_name="N", description="D",
        start_period="2020-01", end_period="2022-12", project_type="internal_audit",
    )
    assert not _project_in_window(p, ("2024-04", "2026-03"))


def test_project_in_window_present():
    p = Project(
        project_id="X", client_name="C", project_name="N", description="D",
        start_period="2022-01", end_period="present", project_type="internal_audit",
    )
    assert _project_in_window(p, ("2024-04", "2026-03"))
