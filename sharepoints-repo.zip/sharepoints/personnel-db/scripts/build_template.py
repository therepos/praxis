"""
Build the Annex E Word template with docxtpl Jinja placeholders.

Mirrors the structure of the IMDA original (Annex E, table-based CV form),
but with {{ variables }} and {%tr for ... %} loops for variable-length sections.
"""
from pathlib import Path

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT = Path(__file__).parent.parent / "app" / "templates" / "annex_e_template.docx"
OUT.parent.mkdir(parents=True, exist_ok=True)


def shade_cell(cell, color_hex):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), color_hex)
    tc_pr.append(shd)


def set_cell_borders(cell):
    tc_pr = cell._tc.get_or_add_tcPr()
    tcBorders = OxmlElement("w:tcBorders")
    for edge in ("top", "left", "bottom", "right"):
        b = OxmlElement(f"w:{edge}")
        b.set(qn("w:val"), "single")
        b.set(qn("w:sz"), "4")
        b.set(qn("w:color"), "808080")
        tcBorders.append(b)
    tc_pr.append(tcBorders)


def add_para(cell, text, bold=False, italic=False, size=10):
    if cell.paragraphs and not cell.paragraphs[0].text:
        p = cell.paragraphs[0]
    else:
        p = cell.add_paragraph()
    run = p.add_run(text)
    run.font.name = "Arial"
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    return p


doc = Document()

# Page setup
section = doc.sections[0]
section.top_margin = Cm(2)
section.bottom_margin = Cm(2)
section.left_margin = Cm(2)
section.right_margin = Cm(2)

# Default font
style = doc.styles["Normal"]
style.font.name = "Arial"
style.font.size = Pt(10)

# Header
h = doc.add_paragraph()
h.alignment = WD_ALIGN_PARAGRAPH.RIGHT
hr = h.add_run("Annex E")
hr.font.name = "Arial"
hr.bold = True
hr.font.size = Pt(11)

title = doc.add_paragraph()
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
tr = title.add_run("LIST OF SUPPLIER'S PERSONNEL TO BE ASSIGNED FOR THE PROJECT")
tr.font.name = "Arial"
tr.bold = True
tr.font.size = Pt(12)

intro = doc.add_paragraph()
ir = intro.add_run(
    "Please fill in for each personnel that will be involved in the audit. "
    "All personnel may be subjected to security clearance after the award of the project."
)
ir.font.name = "Arial"
ir.font.size = Pt(10)

doc.add_paragraph()

# CV table
cv_title = doc.add_paragraph()
cvr = cv_title.add_run("Curriculum Vitae")
cvr.font.name = "Arial"
cvr.bold = True
cvr.font.size = Pt(11)

table = doc.add_table(rows=0, cols=2)
table.style = "Table Grid"
table.autofit = False
table.columns[0].width = Cm(7)
table.columns[1].width = Cm(10)


def add_row(label, value_or_jinja, label_bold=True, label_shade="D9E1F2"):
    row = table.add_row()
    lc, vc = row.cells[0], row.cells[1]
    lc.width = Cm(7)
    vc.width = Cm(10)
    add_para(lc, label, bold=label_bold)
    add_para(vc, value_or_jinja)
    shade_cell(lc, label_shade)
    set_cell_borders(lc)
    set_cell_borders(vc)
    lc.vertical_alignment = WD_ALIGN_VERTICAL.TOP
    vc.vertical_alignment = WD_ALIGN_VERTICAL.TOP
    return row


# Identity
add_row("Name", "{{ name }}")
add_row("Current Position", "{{ current_position }}")
add_row(
    "Proposed Role in this Project\ne.g. Team member, Project Manager, Engagement Partner",
    "{{ proposed_role }}",
)

# Education — variable-length section using {%tr for%} (row-level loop)
# We add a placeholder row containing the loop directives in the label cell.
edu_header = add_row(
    "Education and Training\n[i.e. to state attendance of quality assessment training course or similar training courses, if any]",
    "",
)
# Inside the value cell, render a sub-table-like structure via paragraphs with loop
edu_value = edu_header.cells[1]
edu_value.paragraphs[0].text = ""

p = edu_value.paragraphs[0]
r = p.add_run("{%p for edu in education %}")
r.font.name = "Arial"
r.font.size = Pt(10)

p1 = edu_value.add_paragraph()
r1 = p1.add_run("Course Name & Institution: ")
r1.font.name = "Arial"
r1.font.size = Pt(10)
r1.bold = True
r1b = p1.add_run("{{ edu.course }}")
r1b.font.name = "Arial"
r1b.font.size = Pt(10)

p2 = edu_value.add_paragraph()
r2 = p2.add_run("Year Attained: ")
r2.font.name = "Arial"
r2.font.size = Pt(10)
r2.bold = True
r2b = p2.add_run("{{ edu.year }}")
r2b.font.name = "Arial"
r2b.font.size = Pt(10)

p3 = edu_value.add_paragraph()
r3 = p3.add_run("{%p endfor %}")
r3.font.name = "Arial"
r3.font.size = Pt(10)

# Certifications
cert_header = add_row(
    "Professional Qualifications / Certifications\n[including industry-recognised accreditation and certifications; e.g. Chartered Accountant of Singapore, Certified Internal Auditor]",
    "",
)
cv = cert_header.cells[1]
cv.paragraphs[0].text = ""

p = cv.paragraphs[0]
r = p.add_run("{%p for cert in certifications %}")
r.font.name = "Arial"
r.font.size = Pt(10)

p1 = cv.add_paragraph()
r1 = p1.add_run("Name of Certification: ")
r1.font.name = "Arial"; r1.font.size = Pt(10); r1.bold = True
r1b = p1.add_run("{{ cert.name }}")
r1b.font.name = "Arial"; r1b.font.size = Pt(10)

p2 = cv.add_paragraph()
r2 = p2.add_run("Year Attained: ")
r2.font.name = "Arial"; r2.font.size = Pt(10); r2.bold = True
r2b = p2.add_run("{{ cert.year }}")
r2b.font.name = "Arial"; r2b.font.size = Pt(10)

p3 = cv.add_paragraph()
r3 = p3.add_run("{%p endfor %}")
r3.font.name = "Arial"; r3.font.size = Pt(10)

# Years of relevant audit experience
add_row(
    "Years of Relevant Audit Work Experience:\n(Please state total years of experience, as well as the year of beginning to end/current)",
    "{{ years_of_experience }} Years, started in {{ audit_start_year }} to present",
)

# Projects — variable-length
proj_header = add_row(
    "Relevant Internal Audit Projects completed from {{ window_start | default('1 April 2024') }} to {{ window_end | default('31 March 2026') }}",
    "",
)
pv = proj_header.cells[1]
pv.paragraphs[0].text = ""

p = pv.paragraphs[0]
r = p.add_run("{%p for proj in projects %}")
r.font.name = "Arial"; r.font.size = Pt(10)

# Numbered project block
p_num = pv.add_paragraph()
rn = p_num.add_run("{{ proj.index }}. Company/Client Name: ")
rn.font.name = "Arial"; rn.font.size = Pt(10); rn.bold = True
rnb = p_num.add_run("{{ proj.client_name }}")
rnb.font.name = "Arial"; rnb.font.size = Pt(10)

p_proj = pv.add_paragraph()
rp = p_proj.add_run("Name/Nature of Project: ")
rp.font.name = "Arial"; rp.font.size = Pt(10); rp.bold = True
rpb = p_proj.add_run("{{ proj.project_name }}")
rpb.font.name = "Arial"; rpb.font.size = Pt(10)

p_comp = pv.add_paragraph()
rc = p_comp.add_run("Month/Year of Project Completion: ")
rc.font.name = "Arial"; rc.font.size = Pt(10); rc.bold = True
rcb = p_comp.add_run("{{ proj.completion }}")
rcb.font.name = "Arial"; rcb.font.size = Pt(10)

p_role = pv.add_paragraph()
rr = p_role.add_run("Your Role in Project: ")
rr.font.name = "Arial"; rr.font.size = Pt(10); rr.bold = True
rrb = p_role.add_run("{{ proj.role }}")
rrb.font.name = "Arial"; rrb.font.size = Pt(10)

p_desc = pv.add_paragraph()
rd = p_desc.add_run("{{ proj.description }}")
rd.font.name = "Arial"; rd.font.size = Pt(10)

# Optional contribution notes
p_contrib = pv.add_paragraph()
r_contrib_open = p_contrib.add_run("{%p if proj.contribution_notes %}")
r_contrib_open.font.name = "Arial"; r_contrib_open.font.size = Pt(10)

p_contrib_text = pv.add_paragraph()
rct = p_contrib_text.add_run("Specific contribution: ")
rct.font.name = "Arial"; rct.font.size = Pt(10); rct.italic = True
rctb = p_contrib_text.add_run("{{ proj.contribution_notes }}")
rctb.font.name = "Arial"; rctb.font.size = Pt(10); rctb.italic = True

p_contrib_close = pv.add_paragraph()
r_contrib_close = p_contrib_close.add_run("{%p endif %}")
r_contrib_close.font.name = "Arial"; r_contrib_close.font.size = Pt(10)

# Spacer between projects
pv.add_paragraph()

# End loop
p_end = pv.add_paragraph()
re_ = p_end.add_run("{%p endfor %}")
re_.font.name = "Arial"; re_.font.size = Pt(10)

# Notes section after the table
doc.add_paragraph()

note_intro = doc.add_paragraph()
ni = note_intro.add_run("Notes:")
ni.font.name = "Arial"; ni.font.size = Pt(10); ni.bold = True

note_a = doc.add_paragraph()
na = note_a.add_run("A: ")
na.font.name = "Arial"; na.font.size = Pt(9); na.bold = True
nab = note_a.add_run(
    "Only relevant internal audit projects will be considered for evaluation. "
    "Relevant internal audit projects refer to purely internal audits on business "
    "and/or IT processes. Specialised audits such as ISO and SSAE3402 audits and/or "
    "similar forms of reviews would not be considered."
)
nab.font.name = "Arial"; nab.font.size = Pt(9)

note_b = doc.add_paragraph()
nb = note_b.add_run("B: ")
nb.font.name = "Arial"; nb.font.size = Pt(9); nb.bold = True
nbb = note_b.add_run(
    "IMDA reserves the right not to consider the project for evaluation if the "
    "company or client is not named."
)
nbb.font.name = "Arial"; nbb.font.size = Pt(9)

# Footer with generation date
footer = doc.add_paragraph()
footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
fr = footer.add_run("Generated: {{ generated_at }}")
fr.font.name = "Arial"; fr.font.size = Pt(8); fr.italic = True
fr.font.color.rgb = RGBColor(0x80, 0x80, 0x80)

doc.save(str(OUT))
print(f"Template written: {OUT}")
