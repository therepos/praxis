"""
Build PersonnelDB.exe using PyInstaller.

Streamlit apps need a launcher because PyInstaller can't bundle Streamlit's
runtime directly. The launcher subprocess-runs streamlit with the bundled main.py.
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent
APP = ROOT / "app"
DIST = ROOT / "dist"

LAUNCHER_CODE = '''\
import os, sys, subprocess, webbrowser, time, threading
from pathlib import Path

if getattr(sys, "frozen", False):
    BASE = Path(sys._MEIPASS)
else:
    BASE = Path(__file__).parent

MAIN = BASE / "app" / "main.py"
PORT = "8501"

def open_browser():
    time.sleep(2)
    webbrowser.open(f"http://localhost:{PORT}")

threading.Thread(target=open_browser, daemon=True).start()

subprocess.run([
    sys.executable, "-m", "streamlit", "run", str(MAIN),
    "--server.port", PORT,
    "--server.headless", "true",
    "--browser.gatherUsageStats", "false",
    "--global.developmentMode", "false",
])
'''


def main():
    launcher = ROOT / "scripts" / "_launcher.py"
    launcher.write_text(LAUNCHER_CODE)

    cmd = [
        "pyinstaller",
        "--name", "PersonnelDB",
        "--onefile",
        "--console",
        "--add-data", f"{APP}{';' if sys.platform == 'win32' else ':'}app",
        "--collect-all", "streamlit",
        "--collect-all", "docxtpl",
        "--copy-metadata", "streamlit",
        "--distpath", str(DIST),
        "--workpath", str(ROOT / "build"),
        "--specpath", str(ROOT),
        str(launcher),
    ]
    print("Running:", " ".join(cmd))
    result = subprocess.run(cmd, cwd=ROOT)
    sys.exit(result.returncode)


if __name__ == "__main__":
    main()
