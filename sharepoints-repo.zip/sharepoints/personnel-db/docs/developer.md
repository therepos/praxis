# Developer Guide

## Local development

```bash
cd personnel-db
python -m venv venv
venv\Scripts\activate          # Windows
pip install -r requirements.txt
streamlit run app/main.py
```

Browser opens at `http://localhost:8501`.

For testing without SharePoint, point the app at the seed Excel:
- Open Settings page in the app
- Set Excel path to `personnel_database.xlsx` (the seed file)
- Save

## Project layout

```
app/
├── main.py              Streamlit entry, sidebar nav
├── core/
│   ├── config.py        Persistent settings (APPDATA on Windows)
│   ├── data.py          Pydantic models + Excel loader
│   └── generator.py     docxtpl renderer + PDF conversion
├── pages/
│   ├── staff_directory.py
│   ├── project_library.py
│   ├── generate.py
│   └── settings.py
└── templates/
    └── annex_e_template.docx   Built by scripts/build_template.py

scripts/
├── build_template.py    Rebuilds the Word template from code
└── build.py             PyInstaller .exe builder

tests/
└── test_data.py
```

## Modifying the Annex E template

Two options:

**Option 1 (recommended for layout tweaks):** Edit `app/templates/annex_e_template.docx` directly in Microsoft Word. Preserve the `{{ }}` and `{%p ... %}` Jinja markers exactly. Reference: [docxtpl documentation](https://docxtpl.readthedocs.io/).

**Option 2 (for structural rebuild):** Edit `scripts/build_template.py` and re-run it:
```bash
python scripts/build_template.py
```

## Adding a new schema field

1. Add the column to the SharePoint List
2. Update `docs/sharepoint-setup.md`
3. Update the Power Automate flow to map the new column
4. Update the corresponding Pydantic model in `app/core/data.py`
5. Update the Excel loader in the same file
6. Surface it in the relevant page (`pages/*.py`) or template
7. Tag a new release: `git tag personnel-db-v0.2.0 && git push --tags`

## Releasing

```bash
git tag personnel-db-v0.1.0
git push origin personnel-db-v0.1.0
```

GitHub Actions builds the `.exe` and publishes a Release automatically.

## Versioning

- Schema-breaking changes → major bump (`v1.0.0` → `v2.0.0`)
- New features → minor bump
- Bug fixes → patch bump

Keep `app/core/config.py::VERSION` in sync with the latest tag.

## Testing

```bash
pytest tests/ -v
```

## PDF conversion notes

The generator tries `docx2pdf` first (uses Microsoft Word on Windows), falls back to LibreOffice. End users:
- If they have Word installed → docx2pdf works automatically
- If not → install LibreOffice, no other config needed
- If neither → only DOCX is produced, PDF skipped silently
