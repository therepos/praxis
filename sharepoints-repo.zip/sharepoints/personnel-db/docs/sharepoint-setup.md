# SharePoint Lists Setup Guide

One-time setup. ~30–45 minutes. You need **Edit** permission on the target SharePoint site.

## Overview

You will create **5 Lists** on your SharePoint site:

1. `Personnel`
2. `Education`
3. `Certifications`
4. `Projects`
5. `Personnel_Projects`

Lists 2, 3, and 5 reference List 1 (Personnel) via lookup columns. List 5 also references List 4 (Projects). This is what enforces referential integrity — staff cannot be assigned to a non-existent project.

**Order matters.** Create Lists 1 and 4 first, then 2, 3, and 5 (which reference them).

---

## Pre-flight

- Identify the SharePoint site that will host this. Recommended: a site already restricted to your department.
- Confirm you have **Edit** or **Full Control** permission on that site.
- Open the site in browser. Note the URL (e.g. `https://yourcompany.sharepoint.com/sites/AuditDept`).

---

## List 1: Personnel

1. Site → **+ New** → **List** → **Blank list**
2. Name: `Personnel` (exact, case-sensitive)
3. Description: "Staff master record. One row per person."
4. Show in site navigation: ✓
5. Click **Create**

### Columns (delete default `Title`, then add these)

| Column Name | Type | Settings |
|---|---|---|
| `personnel_id` | Single line of text | **Required**. Max 10 chars. Enforce unique values: ON |
| `full_name` | Single line of text | Required. Max 100 chars |
| `current_position` | Single line of text | Required. Max 50 chars |
| `default_role` | Choice | Required. Choices: `Engagement Partner`, `Project Manager`, `Team Leader`, `Team member`, `Project member` |
| `audit_start_year` | Number | Required. Min 1990, max 2100. No decimals |
| `active` | Yes/No | Required. Default: Yes |
| `notes` | Multiple lines of text | Optional. Plain text |

### Set `personnel_id` as the title-equivalent

1. List Settings (gear icon → List settings)
2. Under Columns, click `personnel_id`
3. Tick **Enforce unique values: Yes**
4. Save

### How to add a staff member (test it)

1. List → **+ New**
2. Fill: personnel_id `P001`, full_name `Ho Ann Sheng`, etc.
3. Save

---

## List 4: Projects

Create this **before** Education/Certifications/Personnel_Projects (the join table needs it).

1. Site → **+ New** → **List** → **Blank list**
2. Name: `Projects`
3. Click **Create**

### Columns

| Column Name | Type | Settings |
|---|---|---|
| `project_id` | Single line of text | Required. Enforce unique: ON. Max 12 chars |
| `client_name` | Single line of text | Required. Max 200 chars |
| `project_name` | Single line of text | Required. Max 200 chars |
| `description` | Multiple lines of text | Required. Plain text. Up to 2000 chars |
| `start_period` | Single line of text | Required. Format: `YYYY-MM` (e.g. `2024-04`) |
| `end_period` | Single line of text | Required. Format: `YYYY-MM` or `present` |
| `project_type` | Choice | Required. Choices: `internal_audit`, `iso`, `ssae3402`, `other` |
| `sector_tags` | Choice (multi-select) | Required. Choices: `government`, `charity`, `commercial`, `statutory_board`, `healthcare`, `education` |
| `domain_tags` | Choice (multi-select) | Required. Choices: `financial_audit`, `it_audit`, `procurement`, `grants`, `governance`, `risk` |

### Notes on Choice columns
- Set type to **Choice**
- Toggle **Allow multiple selections** ON for `sector_tags` and `domain_tags`
- Toggle **Allow fill-in choices** OFF (forces consistent values)

---

## List 2: Education

1. Create new blank list named `Education`

### Columns

| Column Name | Type | Settings |
|---|---|---|
| `education_id` | Single line of text | Required. Enforce unique: ON |
| `personnel_id` | **Lookup** | Required. **Get info from: Personnel**. **Column: personnel_id**. ⚠️ This is the integrity-enforcing column |
| `course_name` | Single line of text | Required. Max 200 chars |
| `institution` | Single line of text | Required. Max 100 chars |
| `year_attained` | Number | Required. No decimals |

### How the Lookup works

When entering data, `personnel_id` becomes a dropdown showing all existing personnel_ids from the Personnel list. **A user cannot type a non-existent ID.** This is the integrity guarantee that solves your concern.

---

## List 3: Certifications

1. Create new blank list named `Certifications`

### Columns

| Column Name | Type | Settings |
|---|---|---|
| `certification_id` | Single line of text | Required. Enforce unique: ON |
| `personnel_id` | **Lookup** | Required. From: **Personnel**, Column: **personnel_id** |
| `name` | Single line of text | Required. Max 200 chars |
| `year_attained` | Number | Required. No decimals |

---

## List 5: Personnel_Projects (the join table)

Create **last** — needs both Personnel and Projects to exist.

1. Create new blank list named `Personnel_Projects`

### Columns

| Column Name | Type | Settings |
|---|---|---|
| `personnel_id` | **Lookup** | Required. From: **Personnel**, Column: **personnel_id** |
| `project_id` | **Lookup** | Required. From: **Projects**, Column: **project_id** |
| `role_on_project` | Choice | Required. Choices: `Engagement Partner`, `Project Manager`, `Team Leader`, `Team Leader and team member`, `Team member`, `Project member` |
| `contribution_notes` | Multiple lines of text | Optional. Up to 1000 chars |

### Important: composite uniqueness

SharePoint can't natively enforce "no duplicate (personnel_id, project_id) pairs" without code. Workaround: create a **calculated column** named `composite_key` with formula `=[personnel_id]&"_"&[project_id]` and enforce unique values on it.

Steps:
1. Add column → **More...** → **Calculated**
2. Name: `composite_key`
3. Formula: `=[personnel_id]&"_"&[project_id]`
4. Return type: Single line of text
5. Save
6. Re-open column settings → Enforce unique values: ON

---

## Permissions

By default, the Lists inherit the site's permissions. If your site is already restricted to the department, you're done. Otherwise:

- List → Settings → **Permissions for this list** → **Stop inheriting permissions**
- Configure as needed

---

## Verification checklist

- [ ] All 5 lists exist on the site
- [ ] `personnel_id`, `project_id`, `education_id`, `certification_id` enforce uniqueness
- [ ] `composite_key` on Personnel_Projects enforces uniqueness
- [ ] Lookup columns (`personnel_id` in Education, Certifications, Personnel_Projects; `project_id` in Personnel_Projects) point to correct source lists
- [ ] You can add a test record in each list without errors
- [ ] Trying to add a Personnel_Projects row with a non-existent personnel_id fails (or rather, the dropdown won't show it)

---

## Migrating existing Excel data

After Lists are set up, bulk-import the seed data from `personnel_database.xlsx`:

1. Open the `.xlsx` from the previous step
2. For each List in SharePoint, click **Edit in grid view**
3. Copy rows from the corresponding Excel sheet, paste into SharePoint grid
4. Save

For Lookup columns, the SharePoint grid lets you paste the literal `personnel_id` value (e.g. `P001`) and it auto-resolves to the lookup. If it fails, type instead of paste.

---

## Next step

→ [Power Automate setup](./power-automate-setup.md)
