# Power Automate Setup Guide

One-time setup. ~20 minutes. Requires Power Automate license (included in most M365 business plans).

## Goal

Create a scheduled flow that runs every hour, reads all 5 Lists, writes them to a single Excel file in a SharePoint document library. The desktop app reads this Excel file from the OneDrive-synced local folder.

```
SharePoint Lists ──[hourly]──> personnel_export.xlsx ──[OneDrive sync]──> User PC
```

---

## Pre-flight

- Confirm SharePoint Lists setup is complete ([guide](./sharepoint-setup.md))
- Identify the SharePoint document library where the export should land (e.g. `Documents/PersonnelDB/`)
- Create the empty target file once: `personnel_export.xlsx` in that library, with 5 empty sheets named exactly: `Personnel`, `Education`, `Certifications`, `Projects`, `Personnel_Projects`. The flow appends rows to existing tables — it does not create the file.
- In each sheet, create an Excel **Table** (Insert → Table) covering the header row only, so Power Automate can target it. Name tables: `tbl_Personnel`, `tbl_Education`, `tbl_Certifications`, `tbl_Projects`, `tbl_PersonnelProjects`.

### Header rows for each sheet

Copy these exactly into row 1 of each sheet before creating the table:

**Personnel:**
```
personnel_id | full_name | current_position | default_role | audit_start_year | active | notes
```

**Education:**
```
education_id | personnel_id | course_name | institution | year_attained
```

**Certifications:**
```
certification_id | personnel_id | name | year_attained
```

**Projects:**
```
project_id | client_name | project_name | description | start_period | end_period | project_type | sector_tags | domain_tags
```

**Personnel_Projects:**
```
personnel_id | project_id | role_on_project | contribution_notes
```

---

## Build the flow

### 1. Create the flow

1. Go to [make.powerautomate.com](https://make.powerautomate.com)
2. **Create** → **Scheduled cloud flow**
3. Name: `PersonnelDB Hourly Export`
4. Starting: now
5. Repeat every: **1 hour**
6. Click **Create**

### 2. Add: Clear existing rows (so we don't accumulate duplicates)

For each of the 5 tables, add an action:

- **+ New step** → search "Excel Online (Business)" → **List rows present in a table**
- Location: SharePoint
- Document Library: your library
- File: `personnel_export.xlsx`
- Table: `tbl_Personnel`

Then add **Apply to each** → output `value` from above → inside loop:
- **Excel Online (Business)** → **Delete a row**
- Same file/table
- Key Column: `personnel_id`
- Key Value: `personnel_id` from current item

**Repeat this clearing pattern for all 5 tables.** Tedious but reliable.

> **Shortcut alternative:** Instead of row-by-row delete, use a "Run script" action with an Office Script that calls `table.delete()` and recreates it. Faster but requires Office Scripts enabled in tenant. See [Optimization](#optimization) below.

### 3. Add: Read SharePoint Lists and write to Excel

For each of the 5 Lists:

#### Personnel

- **+ New step** → **Get items** (SharePoint)
- Site Address: your site
- List Name: `Personnel`
- (no filter, get all)

- **+ New step** → **Apply to each** → output `value`
- Inside: **Excel Online (Business)** → **Add a row into a table**
- File: `personnel_export.xlsx`, Table: `tbl_Personnel`
- Map each column:
  - `personnel_id` ← `personnel_id` from Get items
  - `full_name` ← `full_name`
  - `current_position` ← `current_position`
  - `default_role` ← `default_role` (Choice column → use `.Value`)
  - `audit_start_year` ← `audit_start_year`
  - `active` ← `active`
  - `notes` ← `notes`

#### Repeat for Education, Certifications, Projects, Personnel_Projects

For Lookup columns in dynamic content, use the **Value** subfield, not the lookup object itself:
- e.g. for Education's `personnel_id` → use `personnel_id Value`

For multi-select choice columns (`sector_tags`, `domain_tags` in Projects):
- These come back as arrays. Use a **Compose** action with expression:
  `join(item()?['sector_tags'], ',')`
- Then use the Compose output as the column value (gives you a comma-separated string)

### 4. Save and test

1. Click **Save** (top right)
2. Click **Test** → **Manually** → **Test**
3. Trigger from action panel
4. Watch the run unfold. Each step should turn green.
5. If a step fails, click it to see the error. Most common: column name mismatch, or forgetting `.Value` on Choice/Lookup columns.

### 5. Verify

1. Open `personnel_export.xlsx` in SharePoint
2. Confirm all 5 sheets have data matching the Lists
3. Check OneDrive sync on your local machine — file should appear in your synced folder within ~1 minute

---

## Optimization (optional, recommended once working)

### Replace row-by-row delete with Office Script

The "Apply to each → Delete row" pattern is slow (O(n) API calls per table). Once you've confirmed the flow works, optimize:

1. Open `personnel_export.xlsx` in Excel Online → **Automate** → **New Script**
2. Paste:
   ```ts
   function main(workbook: ExcelScript.Workbook) {
     ['tbl_Personnel','tbl_Education','tbl_Certifications','tbl_Projects','tbl_PersonnelProjects']
       .forEach(name => {
         const table = workbook.getTable(name);
         if (table.getRowCount() > 0) {
           table.getRange().getOffsetRange(1, 0).getResizedRange(table.getRowCount() - 1, 0).delete(ExcelScript.DeleteShiftDirection.up);
         }
       });
   }
   ```
3. Save as `ClearAllTables`
4. In Power Automate, replace the 5 deletion blocks with one **Run script** action calling `ClearAllTables`

Cuts flow runtime from minutes to seconds.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "The file is locked for editing" | Close `personnel_export.xlsx` everywhere (browser, Excel desktop, sync clients) |
| Lookup column writes empty | Use the `.Value` subfield, not the lookup object |
| Multi-choice column writes `["a","b"]` | Use `join(..., ',')` expression in Compose |
| Flow times out | Switch to Office Script optimization above |
| Run history shows success but file empty | Check the table name in Excel — must exactly match (`tbl_Personnel` not `Table1`) |

---

## Verification checklist

- [ ] Flow runs successfully (green check on test run)
- [ ] `personnel_export.xlsx` populated with all 5 sheets matching SharePoint Lists
- [ ] OneDrive sync makes the file visible locally on your PC
- [ ] Schedule confirmed at 1 hour interval
- [ ] Flow owner is set to a service/shared account, not a personal account that might leave the company

---

## Next step

→ Once both setup guides are done, the desktop app (in development) reads from your local OneDrive-synced `personnel_export.xlsx`. No further SharePoint config needed.
